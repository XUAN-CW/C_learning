int counter();

int counter()
{
	int count = 0;
	count++;
	return count;
}
