//#include <stdio.h>
//#include <stdlib.h>
//
//int MeasureArray(int array[]);
//int main()
//{
//	int array[5];
//	printf("%d\n", MeasureArray(array));
//	system("pause");
//	return 0;
//}
//
//
//int MeasureArray(int array[])
//{
//	return  sizeof(array);
//}