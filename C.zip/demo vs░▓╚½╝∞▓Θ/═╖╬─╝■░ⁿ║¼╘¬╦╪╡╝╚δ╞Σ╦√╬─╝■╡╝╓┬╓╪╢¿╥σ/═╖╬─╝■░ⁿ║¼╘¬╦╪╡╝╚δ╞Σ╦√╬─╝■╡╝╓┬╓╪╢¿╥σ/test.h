#pragma once
typedef struct _people
{
	int i;
	int j;
}People;

People people[2]=
{
	{1,2},
	{1,2}
}