#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *text = NULL;
	free(text);
	system("pause");
	return 0;
}
