#include <stdio.h>
#include <stdlib.h>
#include 
int main()
{
	int i;
	i = _getch();
	system("pause");
	return 0;
}
