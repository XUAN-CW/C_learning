#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include "functionOfHandle.h"

int main()
{
	//SetConsoleTitle(L"HANDLE");

	//Test_SetConsoleScreenBufferSize();

	//Test_SetConsoleWindowInfo();

	//Test_SetConsoleCursorPosition();

	Text_FillConsoleOutputAttribute();

	//Test_FillConsoleOutputCharacter();

	//disableCurrsor();

	system("pause");
	return 0;
}
