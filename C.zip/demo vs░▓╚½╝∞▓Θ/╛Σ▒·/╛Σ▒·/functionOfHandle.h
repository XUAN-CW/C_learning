#pragma once

void Test_SetConsoleScreenBufferSize();

void Test_SetConsoleWindowInfo();

void Test_SetConsoleCursorPosition();

void Test_FillConsoleOutputAttribute();

void Test_FillConsoleOutputCharacter();

void disableCurrsor();










