#include <stdio.h>
#include <stdlib.h>
enum DAY
{
	MON = 1, TUE, WED, THU=1, FRI, SAT, SUN
};

int main()
{
	printf("%d\n", WED);
	system("pause");
	return 0;
}
