#include <stdlib.h>
int main()
{
	system("C:\\Users\\Administrator\\Desktop\\̰����6.0.exe");
	return 0;
}