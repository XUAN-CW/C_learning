#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i;
	scanf_s("%d", &i);
	scanf_s("%d", &i);
	printf("%d", i);
	system("pause");
	return 0;
}