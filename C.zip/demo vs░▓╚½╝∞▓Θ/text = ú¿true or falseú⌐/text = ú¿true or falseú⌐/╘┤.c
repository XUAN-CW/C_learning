#include <stdio.h>
#include <stdlib.h>
int main()
{
	int text;
	text = (5 < 6);
	printf("text=%d\n", text);

	text = (5 > 6);
	printf("text=%d\n", text);

	system("pause");
	return 0;
}