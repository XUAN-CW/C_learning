#include <stdio.h>
#include <stdlib.h>
int main()
{ 
	//���һ
	int count = 0; 
	do{
		int count = 0;
		count++;
		printf("count1=%d\n", count);
		count++;
	}while(count < 1);
	printf("count = %d\n", count);
	//�����



	system("pause");
	return 0;

}
