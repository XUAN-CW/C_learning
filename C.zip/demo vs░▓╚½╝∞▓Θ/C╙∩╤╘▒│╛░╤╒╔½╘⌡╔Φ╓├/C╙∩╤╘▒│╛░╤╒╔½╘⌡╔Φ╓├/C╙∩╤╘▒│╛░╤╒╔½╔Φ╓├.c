#include <stdio.h>
#include <stdlib.h>
int main()
{
	system("color A5");
	return 0;
}
