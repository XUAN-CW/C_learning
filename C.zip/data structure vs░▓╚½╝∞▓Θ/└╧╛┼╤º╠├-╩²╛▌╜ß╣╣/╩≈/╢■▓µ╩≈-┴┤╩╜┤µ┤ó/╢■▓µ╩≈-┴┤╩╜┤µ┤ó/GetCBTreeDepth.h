#ifndef LINKEDQUEUE1_H_INCLUDED
#define LINKEDQUEUE1_H_INCLUDED

//#include "CBTree.h"

//int GetCBTreeDepth(CBTree **cbTree);


#endif