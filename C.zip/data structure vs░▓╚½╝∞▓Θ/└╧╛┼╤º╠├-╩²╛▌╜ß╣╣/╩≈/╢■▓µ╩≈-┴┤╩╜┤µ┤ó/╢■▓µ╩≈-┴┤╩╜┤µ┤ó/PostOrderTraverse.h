#pragma once

#include "ElementType.h"

void PostOrderTraverse(TreeNode * node);