#include "CBElementType.h"

//int GetCBTreeDepth(CBTree **cbTree);