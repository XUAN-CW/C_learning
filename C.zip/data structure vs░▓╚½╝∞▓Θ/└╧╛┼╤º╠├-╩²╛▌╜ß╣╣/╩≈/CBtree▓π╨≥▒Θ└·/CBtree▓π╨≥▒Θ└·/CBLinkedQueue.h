#ifndef LINKEDQUEUE1_H_INCLUDED
#define LINKEDQUEUE1_H_INCLUDED

#include "CBElementType.h"

//void InitLinkedQueue(CBLQueue * linkedQueue);
//
//void enCBLQueue(CBLQueue * linkedQueue, CBNode * data);
//
//CBNode * deCBLQueue(CBLQueue * linkedQueue);
//
//int IsLinkedQueueEmpty1(CBLQueue * linkedQueue);

#endif // LINKEDQUEUE1_H_INCLUDED
